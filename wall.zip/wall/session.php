 <?php
//session_start();
//$uid=$_SESSION['user_id']; 
$uid=1; // User Session ID static
?>
